        </div> <!-- END container-fluid -->
    </div> <!-- END content -->

    <footer class="sticky-footer bg-white mt-5 shadow-sm p-3 text-center">
        <div>
            <?= APP_NAME ?> Admin © <?= date('Y') ?>
        </div>
    </footer>

</div> <!-- END content-wrapper -->

</div> <!-- END wrapper -->

<!-- JS LIBS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2/js/sb-admin-2.min.js"></script>

</body>
</html>

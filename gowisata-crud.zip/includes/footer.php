</div>

<footer class="text-center mt-5 p-3 bg-light shadow-sm">
    <?= APP_NAME ?> © <?= date('Y') ?>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2/js/sb-admin-2.min.js"></script>

</body>
</html>

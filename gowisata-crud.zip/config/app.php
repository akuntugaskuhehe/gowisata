<?php

// ================
// APP CONFIG
// ================
define("APP_NAME", "Go-Wisata");
define("APP_URL", "http://localhost/gowisata-crud"); 
// Gunakan domain/web root kamu (tanpa slash akhir)


// ================
// DATABASE CONFIG
// ================
define("DB_HOST", "localhost");
define("DB_NAME", "gowisata_crud");
define("DB_USER", "root");
define("DB_PASS", "");

